# gitr

A simple CLI to Find and Clone your GitHub repos.

I built it as a small helper mostly for my own use, built using Typer and Python.

## Usage

&emsp; [![Hire on Contra](https://me7674.npkn.net/contra-badge/)](https://contra.com/jordan_lowell)
[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/I2I6EMIHA)
