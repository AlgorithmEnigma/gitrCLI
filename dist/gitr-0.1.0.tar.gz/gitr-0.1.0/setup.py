# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src', 'src.utils']

package_data = \
{'': ['*']}

install_requires = \
['python-dotenv>=0.20.0,<0.21.0',
 'requests>=2.28.1,<3.0.0',
 'typer[all]>=0.6.1']

entry_points = \
{'console_scripts': ['gitr = gitr.main:app']}

setup_kwargs = {
    'name': 'gitr',
    'version': '0.1.0',
    'description': 'A small utility tool for finding and cloning your GitHub repos.',
    'long_description': '# gitr\n\nA simple CLI to Find and Clone your GitHub repos.\n\nI built it as a small helper mostly for my own use, built using Typer and Python.\n\n## Usage\n\n&emsp; [![Hire on Contra](https://me7674.npkn.net/contra-badge/)](https://contra.com/jordan_lowell)\n[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/I2I6EMIHA)\n',
    'author': 'Jordan Lowell',
    'author_email': 'me@jordanlowell.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9.5,<4',
}


setup(**setup_kwargs)
